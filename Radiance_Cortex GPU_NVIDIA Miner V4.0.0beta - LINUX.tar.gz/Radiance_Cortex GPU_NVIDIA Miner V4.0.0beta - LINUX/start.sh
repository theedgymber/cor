#version: V4.0.0

export CUDA_VISIBLE_DEVICES=1
./miner -a 0x23df8a88cab54a0e125bf8c6ed265372c32b2fe1 -p cuckoo.cortexmint.com:8008 -w `hostname`


#you can select gpu by set CUDA_VISIBLE_DEVICES
#-a: the cortex account
#-p: the pool uri and port
#-w: the worker name
